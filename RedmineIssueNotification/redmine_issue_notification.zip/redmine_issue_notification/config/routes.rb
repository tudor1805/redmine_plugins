ActionController::Routing::Routes.draw do |map|
  map.resources :notifications
end

